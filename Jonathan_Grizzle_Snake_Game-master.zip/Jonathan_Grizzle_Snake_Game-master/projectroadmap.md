#Task List for Snake Game

1. Read through code to understand what the code is doing. I am needing to look for what each function does as well what can be change
   in the code.-DONE
2. Since the code is messy in it's current state, it needs to be cleaned up and lines need to seperated without ";".-DONE  
3. After looking through the code, I have decided that I would like to change the colors in the game. This includes the background, snake
   and the food blocks. The background should be black, the snake should be yellow, and the food blocks should be blue. To do this, I need to
   research on how to to change the colors.-DONE
4. After I have researched, the next step is to change to the colors. There should be a  website that has the RGB color codes. After I find this website,
   the next step is to change the colors. I need to find where the 3 number codes are in the game, and change it.-DONE
5. The next step is change the message when the the sanke hits the edge. I want to change it to Your amazing score is "Score" + "Points!!!". To do this, I will need to change the code to add the text as well as add the exclamation points.- DONE
6. I want to add a timer to the beginner of the game. This will not allow the user to start the game until the timer is up. It should be
   ten seconds long.-DONE
7. I want to change the color of the score on the top left corner. I want to change it to be red, so it contrasts the snake color. To do this,
   I can change the RGB colors.-DONE
8. I want to add some instructions at the beginning of the game to make sure that users know how to use the game. This should not be too long,
   but it should be a short introduction.-DONE
9. I would like to change the size of the food. Instead of it being a small block, it needs to be bigger blocks. I will have to do research on how to change it. The snake should be changed to match the original proportion.- DONE
10. After the message pops up about the game being over, I would like for a sound to play indicatating that the game is over. I will have to do some research, but I should be pretty simple. It should the last thing that happens before the user exits the game.- DONE
11. I would like for the timer and directions to be in the pygame window and not in the terminal. I think this has to do with blit and render.- DONE
12. I would like to add "Your Score:  "Points!!" to the top of the window where the score count is kept! It should be center instead of the top left corner of the window- DONE 
13. The name of the window needs to be changed to say "Snake Game". This has to do with the set caption line of code.-DONE 
14. I would like make the die message at the very end center on the window. This is very simple to fix with changing the blit line of code.-DONE   
15. Finally, the game needs to be tested to make sure everything works. In this stage, all of the bugs will be worked out to make the final product. -DONE

To be completed in in Sping 2019:

16. Add animation to the end of the game. When the games ends, I would like for the snake to be carried away by a bird. This is will require much effort, so this is take some time to complete. 
17. I would like to find a way to make the game loop endlessly. I think that this would require to put the whole game inside a while True loop. It will difficult to make sure that all of the functions and loops are spaced correctly in order for the game to still run.
18. I would like for the user to be able to pick their color of snake. Since this game only covers the basics of Python, it will be a challenge to let the user chose the color. I know that this will require an input at the beginning of the game. 
19. I would like for the user to see their score from the previous attempt. This will require reading and writing to a file. 
20. Last, I would like to publish this code into the APP store or Google Play, so I can make it into a mobile app on Apple or Andriod. 


