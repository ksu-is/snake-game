Developer: Jonathan Grizzle

Original Developer: Samuel BackMan 

IS 3020 Snake Game 

This is a repository for a library of snake game code. I will post code of different snake games as well as a timer code. 

Here is a general descrition of the game:

After doing research on what to create, I have decided to create a simple snake game program by myself. While this may seem simple, it needs to have a built-in timer to wait 10 seconds before the snake game begins. I chose this game because it is mind-numbing, and I need that after a hard day at school. When you lose the game, it should be able to come up with a graphic that has “Game Over” on it. I would like for it to have  a different color. I would like it to make a sound like after you loose. I would like for it have a simple background of black. The snake should be a yellow color being about 5 blocks long. The obstacle should be a blue square instead of a red square. I am wanting a group of one to work on this. The graphics should not be too intense but have more pop to it than just a simple “Game Over” message that has no color to it. This game is intended to be mind-relaxing, so it needs to have a smooth feel to it. After the game is over, a message needs to appear that gives your score or to some extent. I wanting to pull different snake games together to create a better one. This will require taking code from different websites and pulling what features I like to create a more advanced snake game. The goal is to make it look more modern than the snake game that was loaded into a 90’s Nokia Cell Phone.

URLS: 

Snake games: 
          
https://gist.github.com/sanchitgangwar/2158089

https://www.pygame.org/project/3314
             
https://www.pygame.org/project-Snake+in+35+lines-818-.html
             

Timer: https://gist.github.com/Ashwinning/313a4bed6af3f7599ac168c4de82b555

